<?php
defined('ABS') or die;

//receiving page
if( isset( $_REQUEST['keyword'] ) ) {
	header("Location: /search/".$_REQUEST['keyword']);
	die;
}

if( is_numeric(get_command(0)) ){
	$page = get_command(0);
} else if ( is_numeric(get_command(1)) ){
	$page = get_command(1);
} else {
	$page = 0;
}

if($page==1){
	$start = 0;
} else {
	$start = $page * $page_limit;
}
	
$length = $page_limit;
$break_count = $page_limit * ($page + 1);

$feeds = array();
$categories = get_categories();
if ( count($categories) ){
	foreach ($categories as $cid => $cat){
		$cname = ucfirst($cat['name']);
		$cicon = '';
		if ( isset($cat['icon']) && !empty($cat['icon']) ){
			$cicon = '<i class="'.$cat['icon'].'"></i>';
		}
			
		$all_items = load_all_feeds( get_feed_urls($cat['id']) );
		
		if ( count($all_items) ){
			$feeds[ $cid ] = array(
				'cid' => $cat['id'],
				'cname' => $cname,
				'cicon' => $cicon,
				'feed_count' => count($all_items),
				'founds' => array()
			);
			foreach ( $all_items as $item ){
				if ( !isset($keyword)
						|| empty($keyword)
						|| (preg_match("/$keyword/i", $item->get_title())
							|| preg_match("/$keyword/i", $item->get_content())) ) {
					$feeds[ $cid ]['founds'][] = $item;
				}
			}
		} else {
			$feeds[ $cid ] = array(
					'cid' => $cat['id'],
					'cname' => $cname,
					'cicon' => $cicon,
					'feed_errors' => '',
					'founds' => array()
			);
		}
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<base href="<?php echo $site_url; ?>" />
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<?php if( !empty($keyword) ): ?>
	<meta name="keywords" content="Search <?php echo $keyword; ?> news,read <?php echo $keyword; ?> news,<?php echo $keyword; ?> articles">
	<meta name="description" content="Discover and read <?php echo $keyword; ?> News Articles at <?php echo $site_name; ?>">
	<?php else: ?>
		<?php if( !empty($site_meta_keyword) ): ?>
		<meta name="keywords" content="<?php echo $site_meta_keyword; ?>">
		<?php endif; ?>
		<?php if( !empty($site_meta_description) ): ?>
		<meta name="description" content="<?php echo $site_meta_description; ?>">
		<?php endif; ?>
	<?php endif; ?>
	<title><?php echo $site_name; ?></title>
	<link rel="alternate" type="application/rss+xml" title="<?php echo $site_name; ?> Feed" href="<?php echo get_site_url('feed'); ?>" />
	<link href="assets/ico/favicon.png" rel="shortcut icon">
	<link rel="canonical" href="<?php echo get_current_url(); ?>">
	
	<?php if ( !isset($theme_name) ) $theme_name = 'default'; ?>
	<link href="assets/css/themes/<?php echo $theme_name; ?>/bootstrap.min.css" rel="stylesheet">
	<?php if ( get_setting('enable_rtl') == '1' ): ?>
	<link href="assets/css/bootstrap-rtl.min.css" rel="stylesheet">
	<?php endif; ?>
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="assets/css/app.css" rel="stylesheet">
	
<?php if ( !defined('APP') && get_raw_setting('head_code') ){
	echo get_raw_setting('head_code');
} ?>
</head>
<body id="top" data-spy="scroll" data-target=".subnav" data-offset="80" style="margin-top: 0px;">
	<?php require_once ABS.'/nav.php'; ?>

	<?php if( get_page() != 'search' ){ ?>
	<div class="container">
		<div class="page-header">
        	<h1><?php echo $site_name; ?></h1>
      	</div>
    </div>
	<?php }?>

	<div class="container">
		<?php if( $pageName=="search" ){ ?>
		<div class="page-header">
			<h1>Search</h1>
		</div>
		<header class="object-header">
			<form class="form-search" role="search" action="<?php echo $site_url; ?>" method="get" id="formId">
				<div class="form-group">
					<div class="input-group">
						<span class="input-group-addon"><i class="icon-search"></i> </span>
						<input type="text" name="keyword" id="keywordT" class="form-control" value="<?php echo !empty($keyword) ? $keyword : ""; ?>">
						<span class="input-group-btn">
							<button name="search" class="btn btn-default" type="submit">Search</button>
						</span>
					</div>
				</div>
			</form>
		</header>
		
		<?php } // end search
		
		if ( count($feeds) ){

			$layout_active = isset($default_layout) ? $default_layout : 'list';
			if ( empty($layout_active) ) $layout_active = 'list';
		?>


			<div class="row">
			<div class="text-center"><?php display_banner(1); ?></div>
			<div class="col-md-12"></div>
			<div class="col-md-12">
			<div class="feeds-control pull-right">
				<div id="layout-switcher" class="btn-group visible-lg visible-md visible-sm" data-toggle="buttons">
					<label class="btn btn-primary<?php echo $layout_active=='grid'?' active':''; ?>">
						<input type="radio" name="layout" group="layout" value="grid" <?php echo $layout_active=='grid'?' checked="checked"':''; ?>><i class="icon-th-large"></i>
					</label>
					<label class="btn btn-primary<?php echo $layout_active=='list'?' active':''; ?>">
						<input type="radio" name="layout" group="layout" value="list" <?php echo $layout_active=='list'?' checked="checked"':''; ?>><i class="icon-th-list"></i>
					</label>
				</div>
			</div>
			</div>
			</div>
		<?php
			foreach ( $feeds as $cid => $cdata ){

				$category = get_category_by_id( $cdata['cid'] );
				$items = array_slice($cdata['founds'], $start, $page_limit);
				?>
				<section id="<?php echo $cdata['cname']; ?>" class="feeds <?php echo $layout_active; ?> <?php echo 'category-'.$category['id']; ?>">
					<div class="page-header">
						<h1><a href="<?php echo get_site_url( get_seoname($category['name']) ); ?>"><?php echo $cdata['cicon']; ?> <?php echo $cdata['cname']; ?></a></h1>
					</div>
				
				<?php if ( count($items) ): ?>
					<div class="row">
						<?php foreach ($items as $item): ?>
						<?php
						if ( !($item instanceof SimplePie_Item) ){
							$item = get_cached_item($item);
						}
						$item_url = $site_url.'article/'.get_seoname($cdata['cname']).'/' .get_seoname($item->get_title());
						
						?>
						<div class="media col-xs-12<?php echo $layout_active=='grid'?' col-lg-3 col-md-4 col-sm-6':''; ?>" data-grid="col-lg-3 col-md-4 col-sm-6">
							<a class="pull-left" href="<?php echo $item_url; ?>" <?php if(isset($thumbnail_height) &&$thumbnail_height>0): ?>style="height:<?php echo $thumbnail_height; ?>px; overflow: hidden;"<?php endif; ?>>
								<img class="media-object thumbnail" src="<?php echo get_feed_thumbnail($item, $category) ; ?>" alt="<?php echo $item->get_title(); ?>" />
							</a>
							<div class="media-body">
								<h3 class="media-heading"><a href="<?php echo $item_url; ?>"><?php echo $item->get_title(); ?></a></h4>
								<h4><?php echo $item->get_date(); ?></h4>
							</div>
						</div>
						<?php endforeach; ?>
					</div>
					<p class="text-primary"><a href="<?php echo get_site_url( get_seoname($cdata['cname']) ); ?>">Browse <?php echo ucfirst($cdata['cname']); ?> ...</a></p>
				<?php else: ?>
					<p class="text-primary">No results found in <?php echo ucfirst($cdata['cname']); ?>.</p>
					<p class="text-primary"><a href="<?php echo get_site_url( get_seoname($cdata['cname']) ); ?>">Browse <?php echo ucfirst($cdata['cname']); ?> ...</a></p>
				<?php endif;
			}
			
		}
		
		if ( (!empty($keyword) && $pageName=="search") || (empty($keyword) && $pageName!="search") ){
	  
	   		// set item link to script uri
	    
		   	$max	=	0;
		   	$j	=	1;
		   	$total_found	=	0;

		   	if ( $categories = get_categories() ){
		   		
				if( $page > 1 )
					$prevlink		=	"<a href='".($page-1)."'>Previous</a>";
				else
					$prevlink		=	"";
						
				if(($page*$page_limit+$page_limit)<$max)
					$nextlink		=	"<a href='".($page+1)."'>Next</a>";
				else
					$nextlink		=	"";
						
				$total_category	=	count($category);
						
				if($page==1 || $page==""){
					$begin	=	0*count($category)+1;
					$end	=	$page_limit*$total_category;
				}else{
					$begin	=	($page)*$page_limit*$total_category-($page_limit*$total_category);
					$end	=	($page)*$page_limit*$total_category;
				}
				
				if( isset($keyword) && !empty($keyword) ){
					$total_found	=	$total_found;
					$begin			=	1;
					$end			=	$j-1;
				} else {
					$total_found	=	$max;
				}
			}
		}
		?>
	</div>
	<?php require_once ABS.'/footer.php'; ?>
</body>
</html>