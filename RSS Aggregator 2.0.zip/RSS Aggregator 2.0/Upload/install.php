<?php
require_once dirname(__FILE__).'/functions.php';

if ( isset($_POST['task']) && $_POST['task']=='settings' ){
	$array = array( );
	$user_site_url = '';
	$users = array();
	foreach ( $_POST['settings'] as $row ){
		
		if ( !isset($row['field_name']) || empty($row['field_name']) ){
			continue;
		}
		
		// get admin username
		if ( $row['field_name'] == 'admin_username' ){
			$admin_username = trim(@$row['field_value']);
			if (!empty($admin_username)){
				$users['username'] = $admin_username;
			}
			continue;
		}
		
		// get admin password
		if ( $row['field_name'] == 'admin_password' ){
			$admin_password = trim(@$row['field_value']);
			if (!empty($admin_password)){
				$users['password'] = md5($admin_password);
			}
			continue;
		}
		
		if ( !isset($row['field_value']) || empty($row['field_value']) ){
			$row['field_value'] = '';
		} else {
			$row['field_value'] = filter_var($row['field_value'], FILTER_SANITIZE_STRING);
		}
		
		if ( isset($row['field_name']) && $row['field_name']=='site_url' ){
			$user_site_url = $row['field_value'];
		}
		$array[] = $row;
	}
	
	if ( !isset($users['username']) || empty($users['username']) || !isset($users['password']) || empty($users['password']) ){
		push_message('Please enter valid username and password. IMPORTANT!', 'danger');
	} else {
	
		save_data( array( 'tables' => array( 'settings' => $array, 'users' => $users) ) );
		
		if ( !empty($user_site_url) ){
			// create .htaccess
			if ( file_exists(ABS.'/.htaccess') ){
				// try to backup it
				@copy(ABS.'/.htaccess', ABS.'/.htaccess_old') && @unlink(ABS.'/.htaccess');
			}
			$uri = parse_url($user_site_url, PHP_URL_PATH);
			$htaccess_content = "<IfModule mod_rewrite.c>
	RewriteEngine On
	RewriteBase {$uri}
		
	RewriteCond %{HTTPS} !=on
	RewriteCond %{HTTP_HOST} !=localhost
	RewriteCond %{HTTP_HOST} !^www\..+$ [NC]
	RewriteRule ^ http://www.%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
	
	RewriteCond %{REQUEST_URI} !(.*)/$
	RewriteCond %{REQUEST_FILENAME} !-f
	RewriteRule ^(.*)$ $1/ [L,R]
	
	RewriteRule ^index\.php$ - [L]
	RewriteCond %{REQUEST_FILENAME} !-f
	RewriteCond %{REQUEST_FILENAME} !-d
	RewriteCond %{REQUEST_URI} !(\.css|\.js|\.png|\.jpg|\.gif|robots\.txt|\.shtml)$ [NC]
	RewriteRule . {$uri}index.php [L]
</IfModule>

# Protect the htaccess file
<Files .htaccess>
	Order Allow,Deny
	Deny from all
</Files>

# Protect json
<Files ~ \.json$>
	Order Allow,Deny
	Deny from all
</Files>

";
			file_put_contents(ABS.'/.htaccess', $htaccess_content);
		}
		header('Location: ' . $user_site_url . 'admin/');
		exit;
	
	}
}

if ( !empty($_POST) && isset($array) ){
	$fields = $array;
} else {
	$current_url = get_current_url();
	$default_site_url = preg_replace('#/install.php#', '', $current_url).'/';
	
	$fields = array();
	$fields[] = array(
			'id' => 2,
			'field_name' => 'theme_name',
			'field_value' => 'default'
		);
	$fields[] = array(
			'id' => 4,
			'field_name' => 'site_url',
			'field_value' => $default_site_url
	);
	$fields[] = array(
			'id' => 6,
			'field_name' => 'site_brand',
			'field_value' => ''
	);
	$fields[] = array(
			'id' => 8,
			'field_name' => 'site_name',
			'field_value' => ''
	);
	$fields[] = array(
			'id' => 10,
			'field_name' => 'site_meta_keyword',
			'field_value' => ''
	);
	$fields[] = array(
			'id' => 12,
			'field_name' => 'site_meta_description',
			'field_value' => ''
	);
	$fields[] = array(
			'id' => 14,
			'field_name' => 'page_limit',
			'field_value' => '12'
	);
	$fields[] = array(
			'id' => 16,
			'field_name' => 'category_page_limit',
			'field_value' => '12'
	);
	$fields[] = array(
			'id' => 18,
			'field_name' => 'date_format',
			'field_value' => ''
	);
	$fields[] = array(
			'id' => 20,
			'field_name' => 'simplepie_cache_location',
			'field_value' => realpath(ABS.'/cache')
	);
	$fields[] = array(
			'id' => 22,
			'field_name' => 'simplepie_cache_duration',
			'field_value' => 60 * 60 * 24 * 365
	);
	$fields[] = array(
			'id' => 24,
			'field_name' => 'simplepie_item_limit',
			'field_value' => '1000'
	);
	
	
	$fields[] = array(
			'id' => 26,
			'field_name' => 'preview_frame',
			'field_value' => '1',
			'field_type' => 'select',
			'field_choices' => array(
					'1' => 'Enabled',
					'0' => 'Disabled'
			)
	);
	
	$fields[] = array(
			'id' => 28,
			'field_name' => 'image_excludes',
			'field_value' => ''
	);
	
	$fields[] = array(
			'id' => 30,
			'field_name' => 'rss_limit',
			'field_value' => '10'
	);
	
	
	$fields[] = array(
			'id' => 32,
			'field_name' => 'default_layout',
			'field_value' => 'list',
			'field_type' => 'select',
			'field_choices' => array(
					'grid' => 'Grid',
					'list' => 'List'
			)
	);
	
	$fields[] = array(
			'id' => 33,
			'field_name' => 'enable_rtl',
			'field_value' => '0',
			'field_type' => 'select',
			'field_choices' => array(
					'0' => 'No',
					'1' => 'Yes'
			)
	);
	
	$fields[] = array(
			'id' => 34,
			'field_name' => 'video_width',
			'field_value' => ''
	);
	
	$fields[] = array(
			'id' => 36,
			'field_name' => 'video_height',
			'field_value' => ''
	);
	
	$fields[] = array(
			'id' => 37,
			'field_name' => 'head_code',
			'field_value' => '',
			'field_type' => 'textarea'
	);
	
	$fields[] = array(
			'id' => 38,
			'field_name' => 'footer_code',
			'field_value' => '',
			'field_type' => 'textarea'
	);
	
	$fields[] = array(
			'id' => 39,
			'field_name' => 'front_page_id',
			'field_value' => ''
	);
}

$fields[] = array(
		'id' => 96,
		'field_name' => 'admin_username',
		'field_value' => ''
);

$fields[] = array(
		'id' => 97,
		'field_name' => 'admin_password',
		'field_value' => ''
);

$defaults = array(
	'tables' => array(
		'settings' => $fields
	)
);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<link href="../assets/ico/favicon.png" rel="shortcut icon">
	<title>RSS Aggregator Installation</title>
	<link href="./assets/css/themes/default/bootstrap.min.css" rel="stylesheet">
	
</head>
<body>
	<div class="container">
		<div class="page-header">
        	<h1 class="text-center">Installation : Settings</h1>
      	</div>
      	<?php print_messages(); ?>
      	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
	      	<div class="panel panel-default">
	      		<div class="panel-heading">
					<div class="text-right">
						<button class="btn btn-primary" type="submit"> Save </button>
					</div>
	      		</div>
	      		<div class="panel-body">
	      			<?php
	      				$row_no=0;
	      				
						$settings = $defaults['tables']['settings'];
						
						foreach($settings as $setting_data){
							$row_no++;
							if ( $setting_data['field_name'] == 'theme_name' ){
								$setting_data['field_type'] = 'select';
								$setting_data['field_choices'] = array(
									'amelia'   => 'Amelia',
									'cerulean' => 'Cerulean',
									'cosmo'    => 'Cosmo',
									'cyborg'   => 'Cyborg',
									'default'  => 'Default',
									'flatly'   => 'Flatly',
									'journal'  => 'Journal',
									'readable' => 'Readable',
									'simplex'  => 'Simplex',
									'slate'    => 'Slate',
									'spacelab' => 'Spacelab',
									'united'   => 'United'
								);
							}
							
							if (isset($setting_data['field_name'])){
								$setting_field_cb = $setting_data['field_name'] . '_callback';
								if ( is_callable($setting_field_cb) ){
									$setting_data = call_user_func($setting_field_cb, array('setting'=>$setting_data));
								}
							}
							?>
						<div class="form-group ">
							<label for="Setting<?php echo $row_no; ?>Value" class="col-lg-2 control-label"><?php echo pretty_name($setting_data['field_name']); ?></label>
							<div class="col-lg-10">
								<?php foreach ($setting_data as $attr => $var): ?>
									<?php if ($attr == 'field_value') continue; ?>
									<?php if ( !is_string($var) ): ?>
										<input class="form-control" name="settings[<?php echo $row_no; ?>][<?php echo $attr; ?>]" value="<?php echo json_encode($var); ?>" type="hidden">
									<?php else: ?>
										<input class="form-control" name="settings[<?php echo $row_no; ?>][<?php echo $attr; ?>]" value="<?php echo $var; ?>" type="hidden">
									<?php endif; ?>
								<?php endforeach; ?>
							
								<?php if ( isset($setting_data['field_type']) && $setting_data['field_type']=='select' ): ?>
								<select class="form-control" name="settings[<?php echo $row_no; ?>][field_value]" value="<?php echo $setting_data['field_value']; ?>" id="Setting<?php echo $row_no; ?>Value">
									<?php if ( isset($setting_data['field_choices']) && count($setting_data['field_choices']) ): ?>
									<?php foreach ($setting_data['field_choices'] as $value => $label): ?>
									<option<?php if(isset($setting_data['field_value']) && $setting_data['field_value']==$value) echo ' selected'; ?> value="<?php echo $value; ?>"><?php echo $label; ?></option>
									<?php endforeach; ?>
									<?php endif; ?>
								</select>
								<?php elseif ( isset($setting_data['field_type']) && $setting_data['field_type']=='textarea' ): ?>
								<?php $rows = isset($setting_data['field_rows']) ? $setting_data['field_rows'] : 5;	?>
								<textarea  class="form-control" name="settings[<?php echo $row_no; ?>][field_value]" rows="<?php echo $rows; ?>"><?php echo $setting_data['field_value']; ?></textarea>
								<?php else: ?>
								<input class="form-control" name="settings[<?php echo $row_no; ?>][field_value]" value="<?php echo $setting_data['field_value']; ?>" type="text" id="Setting<?php echo $row_no; ?>Value">
								<?php endif; ?>
							</div>
						</div>
					<?php
						}
					?>
	      			<input type="hidden" name="task" value="settings" />
	      		</div>
	      		<div class="panel-footer">
					<div class="text-right">
						<button class="btn btn-primary" type="submit"> Save </button>
					</div>
				</div>
	      	</div>
	    </form>
    </div>

    <div class="container">
		<footer>
			<div class="row">
				<div class="col-lg-12">
					<p>Copyright &copy; <?php echo date('Y'); ?> by RSS Aggregator.</p>
				</div>
			</div>
		</footer>
	</div>
	
	<script type="text/javascript" src="./assets/js/jquery-2.0.0.min.js"></script>
	<script type="text/javascript" src="./assets/js/bootstrap.min.js"></script>
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</body>
</html>