<?php
$menus = array(
	'categories' => 'Categories',
	'pages' => 'Pages',
	'ads' => 'Ads',
	'settings' => 'Settings',
	'maintenance' => 'Maintenance'
);
?>
<ul class="nav navbar-nav">
	<li <?php if ( !isset($view) || empty($view) ) echo ' class="active"'; ?>><a href="index.php">Dashboard</a></li>
	<?php foreach ($menus as $v => $menu): ?>
	<li <?php if ( $view == $v ) echo ' class="active"'; ?>><a href="index.php?view=<?php echo $v; ?>" title="<?php echo htmlspecialchars($menu); ?>"><?php echo htmlspecialchars($menu); ?></a></li>
	<?php endforeach; ?>
	<?php if ( is_logged_in() ): ?>
	<li><a href="index.php?view=logout">Logout</a></li>
	<?php endif; ?>
</ul>
