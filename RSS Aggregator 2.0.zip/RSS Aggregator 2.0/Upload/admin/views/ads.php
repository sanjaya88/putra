<?php
$banners = get_model( 'banner' );
$banner_id = get( 'id', 0 , $_REQUEST);

if ( $banner_id || get('layout', '', $_REQUEST) == 'edit' ):
	$banner = array();
	if ( count($banners) ){
		foreach ($banners as $i => $bn){
			if ( $banner_id == $bn['id'] ){
				$banner = $banners[$i];
				break;
			}
		}
	}
?>
<div class="container">
	<div class="page-header">
		<h1 class="text-center">Management : Ads <small><?php echo $banner_id ? 'edit advertise': 'new advertise'; ?></small> </h1>
	</div>
	<?php print_messages(); ?>
	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		<div class="panel panel-default">
	      	<div class="panel-heading">
				<div class="text-right">
					<button class="btn btn-success" name="apply"> <i class="icon-save"></i>  Apply </button>
					<button class="btn btn-primary" name="save"> <i class="icon-save"></i>  Save Changes </button>
					<a class="btn btn-default" href="index.php?view=ads"> <i class="icon-level-up"></i> Cancel</a>
				</div>
	      	</div>
	      	<div class="panel-body">
	      		<div class="form-group">
					<label class="col-lg-2 control-label">Ads Name</label>
					<div class="col-lg-8">
						<input class="form-control" name="banner[id]" value="<?php echo get('id', '', $banner); ?>" type="hidden" />
						<input class="form-control" name="banner[title]" value="<?php echo get('title', '', $banner); ?>" type="text"/>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Ads Code</label>
					<div class="col-lg-8">
						<textarea class="form-control" name="banner[content]" rows="5"><?php echo get('content', '', $banner); ?></textarea>
						<?php if (isset($banner['id']) && $banner['id']): ?>
						<div class="help visible-lg">
							Usage: insert this code in your ads areas.
							<pre><code><?php echo htmlentities('<?php display_banner('. $banner['id'] .'); ?>'); ?></code></pre>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<div class="panel-footer">
				<div class="text-right">
					<button class="btn btn-success" name="apply"> <i class="icon-save"></i>  Apply </button>
					<button class="btn btn-primary" name="save"> <i class="icon-save"></i>  Save Changes </button>
					<a class="btn btn-default" href="index.php?view=ads"> <i class="icon-level-up"></i> Cancel</a>
				</div>
      		</div>
		</div>
		<input type="hidden" name="c" value="ads" />
		<input type="hidden" name="task" value="save" />
		<input type="hidden" name="delete" value="" />
	</form>
</div>
<?php
else: ?>
<div class="container">
	<div class="page-header">
		<h1 class="text-center">Management : Ads</h1>
	</div>
	<?php print_messages(); ?>
	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		<div class="panel panel-default">
	      	<div class="panel-heading">
				<div class="text-right">
					<a class="btn btn-success" href="index.php?view=ads&layout=edit"> <i class="icon-plus"></i> New Ads </a>
					<a class="btn btn-default" href="index.php"> <i class="icon-level-up"></i> Back</a>
				</div>
	      	</div>
	      	<div class="panel-body">
	      		<?php if ( count($banners) ): ?>
		      		<div class="form-group">
						<label class="col-lg-1 control-label visible-lg">#</label>
						<div class="col-lg-10 control-label visible-lg" style="text-align: left"><b style="padding-left: 12px;">Ads Name</b></div>
					</div>
				<?php endif; ?>
				<?php
				$j = 0;
				if ( count($banners) ):
					foreach ($banners as $id => $banner){
						$j++;
						$current = $banners[$id];
						?>
						<div class="form-group">
							<label class="col-lg-1 control-label visible-lg"><?php echo $j; ?></label>
							<div class="col-lg-7 col-md-7 col-sm-6 col-xs-6">
								<a class="btn btn-link" href="index.php?view=ads&id=<?php echo $banner['id']; ?>"><?php echo get('title', ''); ?></a>
							</div>
							<div class="col-lg-4 col-md-5 col-sm-6 col-xs-6">
								<div class="text-left">
									<button class="btn btn-danger" type="submit" data-delete="<?php echo $banner['id']; ?>"><i class="icon-trash"></i> Delete </button>
									<a class="btn btn-primary" href="<?php echo get_current_url().'&id='.$banner['id']; ?>"><i class="icon-edit"></i> Edit </a>
								</div>
							</div>
						</div>
						<?php
					}
				else:
				?>
				<p class="lead text-center">There are no ads! <br/>
					<a class="btn btn-success btn-lg" href="index.php?view=ads&layout=edit">Create New Ads Here</a>
				</p>
				<?php
				endif;
				?>
					
			</div>
			<div class="panel-footer">
				<div class="text-right">
					<a class="btn btn-success" href="index.php?view=ads&layout=edit"> <i class="icon-plus"></i> New Ads </a>
					<a class="btn btn-default" href="index.php"> <i class="icon-level-up"></i> Back</a>
				</div>
      		</div>
		</div>
		<input type="hidden" name="c" value="ads" />
		<input type="hidden" name="task" value="update" />
		<input type="hidden" name="delete" value="" />
	</form>
</div>
<?php
endif;
?>