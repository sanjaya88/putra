<?php
$pages = get_model( 'page' );
$page_id = get( 'id', 0 , $_REQUEST);

echo '<!--';
foreach ( $pages as $p ){
	var_dump( $p['created_date'] );
}
echo '-->';

if ( count($pages) ){
	$child_pages = array();
	$parent_pages = array();
	$level_pages = array();
	foreach ( $pages as $page ){
		if ( !isset($page['parent']) || intval($page['parent'])==0 ){
			$parent_pages[ $page['id'] ] = 0;
			if ( !isset($child_pages[0]) ){
				$child_pages[0] = array();
			}
			$child_pages[0][] = $page['id'];
		} else {
			$paren_id = $parent_pages[ $page['id'] ] = intval($page['parent']);
			
			if ( !isset($child_pages[$paren_id]) ){
				$child_pages[$paren_id] = array();
			}
			$child_pages[$paren_id][] = $page['id'];
		}
	}
	foreach ( $parent_pages as $i => $pr ){
		$level_pages[$i] = 0;
		$j = $pr;
		while( isset($parent_pages[$j]) ){
			$level_pages[$i]++;
			$j = $parent_pages[$j];
		}
	}
	$ordered_pages = array();
	$nr = array();
	foreach ( $level_pages as $i => $l ){
		if ( $l > 0 ) continue;
		$q = array( $i );
		while( count($q) ){
			$t = array_shift($q);
			if ( $page_id && $page_id == $t) continue;
			if ( isset($child_pages[$t]) ){
				foreach (array_reverse($child_pages[$t]) as $cp){
					array_unshift($q, $cp);
				}
			}
			array_push($ordered_pages, $t);
		}
	}
}

if ( $page_id || get('layout', '', $_REQUEST) == 'edit' ): $page = get_page_by_id($page_id);

$pages_select = '<select id="page_parent" name="page[parent]" class="form-control">';
$pages_select_options = array(
		'0' => 'Root'
);
if ( count($pages) ){
	foreach ( $ordered_pages as $id ){
		$p = get_page_by_id($id);
		$prefix = '';
		if ( $level_pages[$id] > 0 ){
			$prefix = str_repeat('-- ', $level_pages[$id]);
		}
		$pages_select_options[$id] = $prefix . $p['title'];
	}
}
foreach ($pages_select_options as $i => $j){
	if ( get('parent', 0, $page) == $i ){
		$pages_select .= '<option value="'.$i.'" selected="selected">'.$j.'</option>';
	} else {
		$pages_select .= '<option value="'.$i.'">'.$j.'</option>';
	}
}
$pages_select .= '</select>';

$order_select = '<select id="page_ordering" name="page[ordering]" class="form-control">';
$ref_page_id = $page_id ? $page_id : 0;

$order_selected = false; $order_last_selected = true;
if ( $ref_page_id && isset($parent_pages[$ref_page_id]) ){
	$siblings = $child_pages[$parent_pages[$ref_page_id]];
} else {
	$siblings = @$child_pages[0];
}
if ( $siblings ){
	foreach ( $siblings as $i ){
		if ( $order_selected ){
			$p = get_page_by_id($i);
			$order_selected = false;
			$order_last_selected = false;
			$order_select .= '<option value="'.$i.'" selected="selected">'. $p['title'] . '</option>';
			continue;
		}
		if ( $ref_page_id == $i ){
			$order_selected = true;
			continue;
		}
		$p = get_page_by_id($i);
		$order_select .= '<option value="'.$i.'">'. $p['title'] . '</option>';
	}
}
if ( $order_last_selected ){
	$order_select .= '<option value="last-child" selected="selected">Last</option>';
} else {
	$order_select .= '<option value="last-child">Last</option>';
}
$order_select .= '</select>';

?>
<div class="container">
	<div class="page-header">
		<h1 class="text-center">Management : Pages <small><?php echo $page_id ? 'edit page': 'new page'; ?></small> </h1>
	</div>
	<?php print_messages(); ?>
	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		<div class="panel panel-default">
	      	<div class="panel-heading">
				<div class="text-right">
					<button class="btn btn-success" name="apply"> <i class="icon-save"></i>  Apply </button>
					<button class="btn btn-primary" name="save"> <i class="icon-save"></i>  Save Changes </button>
					<a class="btn btn-default" href="index.php?view=pages"> <i class="icon-level-up"></i> Cancel</a>
				</div>
	      	</div>
	      	<div class="panel-body">
	      		<div class="form-group">
					<label class="col-lg-2 control-label">Page Title</label>
					<div class="col-lg-8">
						<input class="form-control" name="page[id]" value="<?php echo get('id', '', $page); ?>" type="hidden" />
						<input class="form-control" name="page[title]" value="<?php echo get('title', '', $page); ?>" type="text"/>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Date Created</label>
					<div class="col-lg-8">
						<div class="input-group datetimepicker">
							<input class="form-control input-append" data-format="yyyy-MM-dd hh:mm:ss" name="page[created_date]" value="<?php echo get('created_date', '', $page); ?>" type="text"/>
							<span class="input-group-addon add-on"><i class="icon-calendar"></i></span>
						</div>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Page Slug</label>
					<div class="col-lg-8">
						<input class="form-control" name="page[slug]" value="<?php echo ( $current_slug = get('slug', '', $page) ); ?>" type="text"/>
						<?php if( !empty( $current_slug ) ): ?>
						<div class="form-help">
							<a href="<?php echo get_page_link($page); ?>" target="_blank"><?php echo get_page_link($page); ?></a>
						</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Page Parent</label>
					<div class="col-lg-8">
						<?php echo $pages_select; ?>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Page Ordering</label>
					<div class="col-lg-8">
						<?php echo $order_select; ?>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Page Content</label>
					<div class="col-lg-8">
						<textarea id="editor" class="form-control" name="page[content]" rows="5"><?php echo get('content', '', $page); ?></textarea>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Page Image</label>
					<div class="col-lg-8">
						<?php $class_suffix = 'new';
							if ( !empty($page['image']) ){
								$class_suffix = 'exists';
							}
						 ?>
						<div class="fileupload fileupload-<?php echo $class_suffix; ?>" data-provides="fileupload">
							<div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;">
							<?php if(!empty($page['image'])): ?>
								<img src="../<?php echo $page['image']; ?>" />
							<?php endif; ?>
							</div>
							<div>
								<span class="btn btn-default btn-file">
									<span class="fileupload-new">Select image</span>
									<span class="fileupload-exists">Change</span>
									<input type="file" name="page_image" <?php if(!empty($page['image'])): ?> value="<?php echo $page['image']; ?>" <?php endif; ?> />
								</span>
								<a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
							</div>
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-lg-2 control-label">Allow Comment</label>
					<div class="col-lg-8">
						<?php $ac = get('allow_comment', 1, $page); ?>
						<div class="radio">
							<label><input type="radio" <?php if($ac==0): ?>checked="checked"<?php endif; ?> value="0" name="page[allow_comment]"> No</label>
						</div>
						<div class="radio">
							<label><input type="radio" <?php if($ac==1): ?>checked="checked"<?php endif; ?> value="1" name="page[allow_comment]"> Yes</label>
						</div>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-lg-2 control-label">Meta Keywords</label>
					<div class="col-lg-8">
						<textarea class="form-control" name="page[meta_keywords]" rows="2"><?php echo get('meta_keywords', '', $page); ?></textarea>
					</div>
				</div>
				<div class="form-group">
					<label class="col-lg-2 control-label">Meta Description</label>
					<div class="col-lg-8">
						<textarea class="form-control" name="page[meta_description]" rows="2"><?php echo get('meta_description', '', $page); ?></textarea>
					</div>
				</div>
			</div>
			<div class="panel-footer">
				<div class="text-right">
					<button class="btn btn-success" name="apply"> <i class="icon-save"></i>  Apply </button>
					<button class="btn btn-primary" name="save"> <i class="icon-save"></i>  Save Changes </button>
					<a class="btn btn-default" href="index.php?view=pages"> <i class="icon-level-up"></i> Cancel</a>
				</div>
      		</div>
		</div>
		<input type="hidden" name="c" value="page" />
		<input type="hidden" name="task" value="save" />
		<input type="hidden" name="delete" value="" />
	</form>
</div>
<?php
else: ?>
<div class="container">
	<div class="page-header">
		<h1 class="text-center">Management : Pages</h1>
	</div>
	<?php print_messages(); ?>
	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		<div class="panel panel-default">
	      	<div class="panel-heading">
				<div class="text-right">
					<a class="btn btn-success" href="index.php?view=pages&layout=edit"> <i class="icon-plus"></i> New Page </a>
					<a class="btn btn-default" href="index.php"> <i class="icon-level-up"></i> Back</a>
				</div>
	      	</div>
	      	<div class="panel-body">
	      		<?php if ( count($pages) ): ?>
		      		<div class="form-group">
						<label class="col-lg-1 control-label visible-lg">#</label>
						<div class="col-lg-10 control-label visible-lg" style="text-align: left"><b style="padding-left: 12px;">Page Name</b></div>
					</div>
				<?php endif; ?>
				<?php
				$j = 0;
				if ( count($pages) ):
					foreach ( $ordered_pages as $id ){
						$page = get_page_by_id($id);
						$prefix = '';
						if ( $level_pages[$id] > 0 ){
							$prefix = str_repeat('-- ', $level_pages[$id]);
						}
						?>
							
						<div class="form-group">
							<label class="col-lg-1 control-label"><?php echo $page['ordering']; ?></label>
							<div class="col-lg-7">
								<a class="btn btn-link" href="index.php?view=pages&id=<?php echo $page['id']; ?>"><?php echo $prefix . $page['title'] ; ?></a>
							</div>
							<div class="col-lg-4">
								<div class="text-left">
									<button class="btn btn-danger" type="submit" data-delete="<?php echo $page['id']; ?>"><i class="icon-trash"></i> Delete </button>
									<a class="btn btn-primary" href="<?php echo get_current_url().'&id='.$page['id']; ?>"><i class="icon-edit"></i> Edit </a>
									<a class="btn btn-info" href="<?php echo get_page_link($page); ?>"><i class="icon-external-link"></i> View </a>
								</div>
							</div>
						</div>
						<?php
					}
					
				else:
				?>
				<p class="lead text-center">There are no pages! <br/>
					<a class="btn btn-success btn-lg" href="index.php?view=pages&layout=edit">Create New Page Here</a>
				</p>
				<?php
				endif;
				?>
					
			</div>
			<div class="panel-footer">
				<div class="text-right">
					<a class="btn btn-success" href="index.php?view=pages&layout=edit"> <i class="icon-plus"></i> New Page </a>
					<a class="btn btn-default" href="index.php"> <i class="icon-level-up"></i> Back</a>
				</div>
      		</div>
		</div>
		<input type="hidden" name="c" value="page" />
		<input type="hidden" name="task" value="update" />
		<input type="hidden" name="delete" value="" />
	</form>
</div>
<?php
endif;
?>