<?php
defined('ABS') or die;
?>
<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
  	<!-- Brand and toggle get grouped for better mobile display -->
  	<div class="navbar-header">
    	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
      		<span class="sr-only">Toggle navigation</span>
      		<span class="icon-bar"></span>
      		<span class="icon-bar"></span>
      		<span class="icon-bar"></span>
    	</button>
    	<a class="navbar-brand" href="<?php echo $site_url; ?>"><?php
    		if ( isset($site_brand) && !empty($site_brand) ):
	    		$brand_content = '';
	    		if ( preg_match('/^icon-([a-z]+)$/i', $site_brand) ){
					$brand_content = '<i class="'. strtolower($site_brand)  .'"></i>';
				} else {
					$brand_content = '<img src="'.$site_brand.'" alt="'.$site_name.'"/>';
				}
				echo $brand_content;
			endif; ?><?php echo $site_name; ?></a>
  	</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
	<div class="navbar-collapse collapse navbar-responsive-collapse navbar-ex1-collapse nowrap">
		<?php if ( $categories = get_categories() ): ?>
		<ul class="nav navbar-nav">
		<?php $count = 0; $dropdown_these = array(); ?>
		<?php foreach( $categories as $cid => $cat ){ $count++; ?>
			<?php if($count>5){ $dropdown_these[$cid] = &$categories[$cid]; continue; } ?>
			<li class="<?php echo (get_command(0) == get_seoname($cat['name'])) ? 'active' : ''; ?>"><a href="<?php echo get_site_url( get_seoname($cat['name']) ); ?>"><?php echo ucfirst($cat['name']); ?></a></li>
		<?php } ?>
		<?php if ( count($dropdown_these) ): ?>
			<li class="dropdown">
				<a href="#" data-toggle="dropdown">More <b class="caret"></b></a>
				<ul class="dropdown-menu">
					<?php foreach( $dropdown_these as $cid => $cat ){ ?>
						<li class="<?php echo (get_command(0) == get_seoname($cat['name'])) ? 'active' : ''; ?>"><a href="<?php echo get_site_url( get_seoname($cat['name']) ); ?>"><?php echo ucfirst($cat['name']); ?></a></li>
					<?php } ?>
				</ul>
			</li>
		<?php endif; ?>
		</ul>
		<?php endif; ?>
		
    	<form id="navbar-search-form" class="navbar-form navbar-left" role="search" action="" method="get">
      		<div class="form-group">
				<div class="input-group">
		        	<input type="text" name="keyword" id="keywordT" class="form-control" placeholder="Search" value="<?php echo isset($keyword) ? $keyword : ''; ?>">
		        	<span class="input-group-btn"><button type="submit" class="btn btn-default">Submit</button></span>
		      	</div>
      		</div>
    	</form>
	</div>
</nav>