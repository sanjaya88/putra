<?php
require_once dirname(__FILE__).'/functions.php';
$no_cache = true;
$cron_new_count = 0;

$feeds = array();
$categories = get_categories();
if ( count($categories) ){
	foreach ($categories as $cid => $cat){
		$cname = ucfirst($cat['name']);
		$cicon = '';
		if ( isset($cat['icon']) && !empty($cat['icon']) ){
			$cicon = '<i class="'.$cat['icon'].'"></i>';
		}
		
		$all_items = load_all_feeds( get_feed_urls($cat['id']) );
		
		if ( count($all_items) ){
			$feeds[ $cid ] = array(
				'cid' => $cat['id'],
				'cname' => $cname,
				'cicon' => $cicon,
				'feed_count' => count($all_items),
				'founds' => array()
			);
			foreach ( $all_items as $item ){
				if ( !isset($keyword)
						|| empty($keyword)
						|| (preg_match("/$keyword/i", $item->get_title())
							|| preg_match("/$keyword/i", $item->get_content())) ) {
					$feeds[ $cid ]['founds'][] = $item;
				}
			}
		} else {
			$feeds[ $cid ] = array(
					'cid' => $cat['id'],
					'cname' => $cname,
					'cicon' => $cicon,
					'feed_errors' => '',
					'founds' => array()
			);
		}
	}
}
echo 'Add ' . $cron_new_count . ' item(s) new!<br/>';
?>

