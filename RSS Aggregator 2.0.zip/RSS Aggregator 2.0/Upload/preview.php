<!DOCTYPE html>
<html lang="en">
<head>
	<base href="<?php echo $site_url; ?>" />
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta name="description" content="Preview on RSS WebSite Generator">
	<meta name="keywords" content="">
	
	<title><?php echo $site_name; ?></title>
	<link href="assets/ico/favicon.png" rel="shortcut icon">
	<link rel="canonical" href="<?php echo $site_url; ?>">
	
	<?php if ( !isset($theme_name) ) $theme_name = 'default'; ?>
	<link href="assets/css/themes/<?php echo $theme_name; ?>/bootstrap.min.css" rel="stylesheet">
	<?php if ( get_setting('enable_rtl') == '1' ): ?>
	<link href="assets/css/bootstrap-rtl.min.css" rel="stylesheet">
	<?php endif; ?>
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<style type="text/css">
		html,
		body {
		  height: 100%;
		  overflow: hidden;
		  margin: 0;
		  /* The html and body elements cannot have any padding or margin. */
		}
	    #preview-frame {
		    background-color: #FFFFFF;
		    width: 100%;
		}
		
	</style>
<?php if ( !defined('APP') && get_raw_setting('head_code') ){
	echo get_raw_setting('head_code');
} ?>
</head>
<body>
	<!-- Fixed navbar -->
	<div id="header-bar" class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header pull-right">
		    	<a class="navbar-brand" href="<?php echo $site_url; ?>"><?php echo $site_name; ?></a>
		  	</div>
		  	<ul class="nav navbar-nav">
				<li><a href="<?php echo urldecode(get('url', '', $_GET)); ?>" class="remove"><i class="icon-remove-circle"></i> Remove Frame</a></li>
				<li><a href="#">|</a></li>
				<li><a href="javascript::void();" onclick="history.go(-1);" class="remove">Back</a></li>
			</ul>
		</div>
	</div>
	<iframe frameborder="0" noresize="noresize" name="preview-frame" src="<?php echo urldecode(get('url', '', $_GET)); ?>" id="preview-frame"></iframe>
	<?php if ( isset($google_analytics) ): ?>
	<script>
		(function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
		function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
		e=o.createElement(i);r=o.getElementsByTagName(i)[0];
		e.src='//www.google-analytics.com/analytics.js';
		r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
		ga('create','<?php echo $google_analytics; ?>');ga('send','pageview');
	</script>
	<?php endif; ?>
	<script type="text/javascript" src="assets/js/jquery-2.0.0.min.js"></script>
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script type="text/javascript">
		var calcHeight = function() {
			var headerDimensions = $('#header-bar').height();
			$('body').css('padding-top', headerDimensions);
			$('#preview-frame').height($(window).height() - headerDimensions);
		}
		$(document).ready(function($){
	        calcHeight();
		});
		$(window).resize(function() {
			calcHeight();
		}).load(function() {
			calcHeight();
		});
	</script>
</body>
</html>