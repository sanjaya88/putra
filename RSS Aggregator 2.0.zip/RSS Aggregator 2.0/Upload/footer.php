<?php
defined('ABS') or die;

if ( $categories = get_categories() ){
	
	$all_items = load_all_feeds( get_feed_urls() );
	
	$totalfeed = count($all_items);
} else {
	$totalfeed = 0;
}
?>
<div class="container">
	<hr/>
	<footer>
		<div class="row">
			<div class="col-lg-12">
				<ul class="list-inline">
					<?php if (get_setting('enable_rtl') == '1'): ?>
					<li class="pull-left"><a href="#top">Back to top</a></li>
					<?php else: ?>
					<li class="pull-right"><a href="#top">Back to top</a></li>
					<?php endif; ?>
					<?php if ( count( $pages = get_model('page') ))
						foreach ($pages as $page): ?>
					<li><a href="<?php echo get_page_link($page); ?>" title="<?php echo $page['title']; ?>"><?php echo $page['title']; ?></a></li>
					<?php endforeach; ?>
					
					<li><a href="<?php echo get_site_url('feed'); ?>">RSS</a></li>
					
					<li><a href="#">Total posts <span class="badge"><?php echo $totalfeed; ?> </span></a></li>
				</ul>
				<p>Copyright &copy; <?php echo date('Y'); ?> by <?php echo $site_name; ?> <?php echo VERSION; ?>.</p>
			</div>
		</div>
	</footer>
</div>

<script type="text/javascript" src="assets/js/jquery-2.0.0.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script type="text/javascript">
	jQuery(document).ready(function($){
		
		<?php if ( isset($preview_frame) && $preview_frame ): ?>
		$(document).on('click', '[data-toggle="preview"]', function(e){
			$(this).attr('href', '<?php echo $site_url.'preview/?url='; ?>' + $(this).attr('href') );
			e.stopPropagation();
		});
		<?php endif; ?>
		
		$('#layout-switcher').on('click', 'label.btn', function(e){
			var $this = $(this), type = $this.find('input').val(), container = $('.feeds'), medias = $('.media', container);
			if ( type == 'grid' ){
				container.removeClass('list');
				container.addClass(type);
				medias.each(function(){
					var media = $(this), md = media.data();
					return media.addClass(md.grid);
				});
			} else if ( type == 'list' ) {
				container.removeClass('grid');
				container.addClass(type);
				medias.each(function(){
					var media = $(this), md = media.data();
					return media.removeClass(md.grid);
				});
			}
		});
	});
</script>
<?php if ( !defined('APP') && get_raw_setting('footer_code') ){
	echo get_raw_setting('footer_code');
} ?>